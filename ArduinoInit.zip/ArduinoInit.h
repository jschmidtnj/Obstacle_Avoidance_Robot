//**************************************************************************************************************
//ArduinoInit.h - This header file is to be used in confuction with source code file ArduinoInit.cpp
//Written by Prof. Edward Blicharz, Stevens Institute of Technology, Hoboken, NJ
//VERSION 13F-01 (September 14, 2013)  Baseline
//VERSION 13F-02 (October 3, 2013)
//VERSION 14F-01 (May 22, 2014)
//VERSION 15S-01 (Jnauary 12, 2015)
//VERSION 15S-02 (April 2, 2015)
//**************************************************************************************************************

#ifndef ArduinoInit_h
#define ArduinoInit_h

	#include "Arduino.h"
	#include <SendOnlySoftwareSerial.h>

	#define NOP __asm__ __volatile__ ("nop\n\t")

	#ifndef GCC_VERSION
	#define GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)
	#endif

	// Adjust Pause() timing according to new vs. old AVR toolchain
	#if GCC_VERSION >= 40801
		#define pause_loop_cnt 2640
	#else
		#define pause_loop_cnt 1760
	#endif

	//Prototype functions defined in the ArduinoInit.cpp file

	void configArduino ();
	void motors (char motor, char direction, int speed);
	void commandMotors (char motor, char direction, int speed);
	unsigned int readADC (byte pin);
	void outputHigh (byte pin);
	void outputLow (byte pin);
	byte readInput (byte pin);
	void pause (unsigned int time);
	void tempINT ();
	void flashErrorLED (byte routineID);
	void version ();

#endif
